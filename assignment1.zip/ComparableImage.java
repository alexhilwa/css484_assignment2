import java.awt.image.BufferedImage;
import java.lang.Object.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;
import java.awt.Color;
import java.lang.Math;

//This class represents a BufferedImage object that can be compared against others
//with its color code and intensity.
public class ComparableImage implements Comparable<ComparableImage>
{
    static final int INTENSITY = 1;
    static final int COLORCODE = 2;
    public BufferedImage image;
    public int height;
    public int width;
    public int size;
    public String filename;
    public int method = INTENSITY;
    public Double[] intensity = new Double[26];
    public Double[] colorCodes = new Double[64]; 
    public int[] scores = new int[100];

    public int index;
    public ComparableImage compareTarget = null;
    public double colorCodeScoreWithCompareTarget = 0.0;
    public double intensityScoreWithCompareTarget = 0.0;

    //constructor accepts a BufferedImage and a unique number identifier for the image
    public ComparableImage(BufferedImage newImage, int index)
    {
        this.index = index;
        image = newImage;
        height = image.getHeight();
        width = image.getWidth();
        size = height * width;
    }

    //This method accepts another ComparableImage and recalculates the distances for
    //intensity and colorCode between itself and the other image.
    public void setCompareTarget(ComparableImage other)
    {
        compareTarget = other;
        intensityScoreWithCompareTarget = getIntensityScore(other);
        colorCodeScoreWithCompareTarget = getColorCodeScore(other);
    }

    //This method sets the method by which the images are compared.
    //Either intensity or color code.
    public boolean setMethod(int newMethod)
    {
        if(method == INTENSITY || method == COLORCODE)
        {
            method = newMethod;
            return true;
        }
        else
        {
            return false;
        }
    }

    //This method sets the image's intensity bins.
    public boolean setIntensity(Double[] newIntensity)
    {
        if(newIntensity.length != 26)
        {
            return false;
        }
        intensity = newIntensity;
        return true;
    }

    //This method sets the image's color code bins.
    public boolean setColorCodes(Double[] newColorCodes)
    {
        if(newColorCodes.length != 64)
        {
            return false;
        }
        colorCodes = newColorCodes;
        return true;
    }

    //This method calculates the intensity distance between this image and another.
    private double getIntensityScore(ComparableImage other)
    {
        double score = 0;
        for(int i = 0; i < intensity.length - 1; i++)
        {
            score += Math.abs((intensity[i] / size) - (other.intensity[i] / other.size));
        }
        return score;
    }

    //This method calculates the color code distance between this image and another.
    private double getColorCodeScore(ComparableImage other)
    {
        double score = 0;
        for(int i = 0; i < colorCodes.length - 1; i++)
        {
            score += Math.abs((colorCodes[i] / size) - (other.colorCodes[i] / other.size));
        }
        return score;
    }
    
    //This method overrides Comparable's compareTo
    public int compareTo(ComparableImage other)
    {
        double myScore = 0.0;
        double otherScore = 0.0;
        if(method == INTENSITY)
        {
            if(this.intensityScoreWithCompareTarget > other.intensityScoreWithCompareTarget)
            {
                return -1; //other image has a lower distance, is closer
            }
            else if(this.intensityScoreWithCompareTarget < other.intensityScoreWithCompareTarget)
            {
                return 1; //this image has as lower distance, is closer
            }
            else //images have equal distance (somehow)
            {
                return 0;
            }
        }
        else if(method == COLORCODE)
        {
            if(this.colorCodeScoreWithCompareTarget > other.colorCodeScoreWithCompareTarget)
            {
                return -1; //other image has a lower distance, is closer
            }
            else if(this.colorCodeScoreWithCompareTarget < other.colorCodeScoreWithCompareTarget)
            {
                return 1; //other image has a lower distance, is closer
            }
            else //images have equal distance
            {
                return 0;
            }
        }
        System.out.println("This should never happen. Ever.");
        return 0;
    }

}
